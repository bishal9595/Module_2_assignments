export class Basic{
   
    MobileType:string;
   
   
   static  printType():any{
        return "BasicPhone";
    }
}